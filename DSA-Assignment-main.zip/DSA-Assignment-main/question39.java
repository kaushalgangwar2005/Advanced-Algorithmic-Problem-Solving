// Algorithm:
// Subsets: All combinations without order (e.g., [1], [2,1] == [1,2])
// Permutations: All arrangements with order (e.g., [1,2] != [2,1])

public class question39 {
    public static void main(String[] args) {
        System.out.println("Subsets are all combinations of elements. Permutations are all orderings.");
    }
}

// Time Complexity: NA
// Space Complexity: NA
