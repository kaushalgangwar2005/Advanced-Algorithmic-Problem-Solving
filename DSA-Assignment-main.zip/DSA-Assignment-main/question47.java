// Algorithm:
// Histogram problems often use stacks to calculate areas.
// Applications:
// - Largest rectangle
// - Trapping rain water
// - Monotonic stack techniques

public class question47 {
    public static void main(String[] args) {
        System.out.println("Histogram problems are solved using stack to find max area or trapped water.");
    }
}

// Time Complexity: NA
// Space Complexity: NA
